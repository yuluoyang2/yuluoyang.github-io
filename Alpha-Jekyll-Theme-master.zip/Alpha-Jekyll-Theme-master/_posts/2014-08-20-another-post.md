---
title: Lorem Ipsum Dolor Sit Amet
layout: post
---

<span class="image featured"><img src="{{ site.baseurl }}/assets/images/pic02.jpg" alt=""></span>
<h3>Non aute irure</h3>
<p>Integer volutpat ante et accumsan commophasellus sed aliquam feugiat lorem aliquet ut enim rutrum phasellus iaculis accumsan dolore magna aliquam veroeros.</p>
<p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
